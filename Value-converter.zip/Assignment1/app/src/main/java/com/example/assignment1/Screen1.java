package com.example.assignment1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Screen1 extends AppCompatActivity {
    private EditText etKM, etMiles;
    private Button btCalculate, btBack;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen1);

        this.setTitle("KM to miles");
        etKM = findViewById(R.id.etKM);
        etMiles = findViewById(R.id.etMiles);
        loadButtons();
    }

    private void loadButtons() {
        btCalculate = findViewById(R.id.btCalculate);
        btBack = findViewById(R.id.btBack);

        btCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SavedData.calculateMiles(Double.parseDouble(etKM.getText().toString()));
                etMiles.setText(String.format("%.2f", SavedData.getMiles()));
            }
        });

        btBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), MainActivity.class);
                startActivity(myIntent);
            }
        });
    }
}