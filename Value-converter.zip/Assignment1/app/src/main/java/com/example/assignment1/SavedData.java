package com.example.assignment1;

public final class SavedData {
    private SavedData(){}

    private static double vKM, vMiles, cMileRate = 1.609, vLB, vKG, cKGRate = 2.205, vFeet, vInches, cInchRate = 12;

    public static void calculateMiles(double xKM){
        vKM = xKM;
        vMiles = vKM / cMileRate;
    }
    public static void calculateKGs(int xLB){
        vLB = xLB;
        vKG = vLB / cKGRate;
    }
    public static void calculateInches(double xFeet){
        vFeet = xFeet;
        vInches = vFeet * cInchRate;
    }
    public static double getInches() {
        return vInches;
    }
    public static double getMiles() {
        return vMiles;
    }
    public static String getKMtoMilesLastCalc(){
        //return Double.toString(vKM) + " KM = "
                //+ Double.toString(vMiles) + " miles";
        return String.format("%.2f", vKM) + " KM = "
        + String.format("%.2f", vMiles) + " miles";
    }
    public static String getLBtoKGLastCalc(){
        //return Double.toString(vLB) + " LBs = "
        //        + Double.toString(vKG) + " KGs";
        return String.format("%.0f", vLB) + " LBs = "
                + String.format("%.2f", vKG) + " KGs";
    }
    public static String getFeettoInchesLastCalc(){
        return Double.toString(vFeet) + " Feet = "
                + Double.toString(vInches) + " Inches";
    }
}
