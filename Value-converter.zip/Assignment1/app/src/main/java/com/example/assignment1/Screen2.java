package com.example.assignment1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class Screen2 extends AppCompatActivity {

    private TextView tvKGs;
    private Button btBack;
    private SeekBar sbLBs;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen2);
        this.setTitle("LBs TO KGs");
        tvKGs = findViewById(R.id.tvKGs);
        btBack = findViewById(R.id.btBack);
        sbLBs = findViewById(R.id.sbLBs);
        sbLBs.setMax(1000);
        sbLBs.setMin(50);
        sbLBs.setProgress(50);

        sbLBs.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            //int progressValue = 0;
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                //progressValue = i;
                SavedData.calculateKGs(i);
                tvKGs.setText(SavedData.getLBtoKGLastCalc());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                /*SavedData.calculateKGs(progressValue);
                tvKGs.setText(SavedData.getLBtoKGLastCalc());*/
            }
        });

        btBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), MainActivity.class);
                startActivity(myIntent);
            }
        });
    }
}