package com.example.assignment1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Screen3 extends AppCompatActivity {

    private EditText etFeet, etInches;
    private Button btCalculate, btBack;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen3);
        this.setTitle("KM to miles");
        etFeet = findViewById(R.id.etFeet);
        etInches = findViewById(R.id.etInches);
        loadButtons();
    }

    private void loadButtons() {
        btCalculate = findViewById(R.id.btCalculate);
        btBack = findViewById(R.id.btBack);

        btCalculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(etFeet.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(), "Input feet value", Toast.LENGTH_LONG ).show();
                }
                else{
                SavedData.calculateInches(Double.parseDouble(etFeet.getText().toString()));
                etInches.setText(String.format("%.2f", SavedData.getInches()));
                }
            }
        });

        btBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), MainActivity.class);
                startActivity(myIntent);
            }
        });
    }
}