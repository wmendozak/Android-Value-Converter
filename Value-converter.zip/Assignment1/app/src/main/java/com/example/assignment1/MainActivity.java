package com.example.assignment1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView tvKMtoMiles, tvFeettoInches, tvLBtoKG;
    private Button btKMtoMiles, btFeettoInches, btLBtoKG;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvKMtoMiles = findViewById(R.id.tvKMtoMiles);
        tvFeettoInches = findViewById(R.id.tvFeettoInches);
        tvLBtoKG = findViewById(R.id.tvLBtoKG);
        loadButtons();
        loadData();
    }

    private void loadData() {
        tvKMtoMiles.setText(SavedData.getKMtoMilesLastCalc());
        tvFeettoInches.setText(SavedData.getFeettoInchesLastCalc());
        tvLBtoKG.setText(SavedData.getLBtoKGLastCalc());
    }

    private void loadButtons() {
        btFeettoInches = findViewById(R.id.btFeettoInches);
        btLBtoKG = findViewById(R.id.btLBtoKG);
        btKMtoMiles = findViewById(R.id.btKMtoMiles);

        btKMtoMiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), Screen1.class);
                startActivity(myIntent);
            }
        });
        btFeettoInches.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), Screen3.class);
                startActivity(myIntent);
            }
        });
        btLBtoKG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(view.getContext(), Screen2.class);
                startActivity(myIntent);
            }
        });
    }
}